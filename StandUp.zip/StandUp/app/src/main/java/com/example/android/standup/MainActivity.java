package com.example.android.standup;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    NotificationManager mNotificationManager;
    // A  constant  variable  for the notification  ID
    private static final int NOTIFICATION_ID = 0;
    // Create a string  constant  as  a member  variable
    private static final String ACTION_NOTIFY =
            "com.example.android.standup.ACTION_NOTIFY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        final AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            alarmManager.getNextAlarmClock();
        }

        ToggleButton alarmToggle = (ToggleButton) findViewById(R.id.alarmToggle);
        Button nextAlarm = (Button) findViewById(R.id.nextalarmToggle);

        //Set up the Notification Broadcast Intent
        Intent notifyIntent = new Intent(this, AlarmReceiver.class);

        //Check if the Alarm is already set, and check the toggle accordingly
        boolean alarmUp = (PendingIntent.getBroadcast(this, 0, notifyIntent,
                PendingIntent.FLAG_NO_CREATE) != null);

        alarmToggle.setChecked(alarmUp);

        //Set up the PendingIntent for the AlarmManager
        final PendingIntent notifyPendingIntent = PendingIntent.getBroadcast
                (this, NOTIFICATION_ID, notifyIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        alarmToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                String toastMessage;
                if(isChecked){

                    long triggerTime = SystemClock.elapsedRealtime()
                            + AlarmManager.INTERVAL_FIFTEEN_MINUTES;

                    long repeatInterval = AlarmManager.INTERVAL_FIFTEEN_MINUTES;

                    //If the Toggle is turned on, set the repeating alarm with a 15 minute interval
                    alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                            triggerTime, repeatInterval, notifyPendingIntent);

                    //Set the toast message for the "on" case
                    toastMessage = getString(R.string.alarm_on_toast);
                } else {
                    //Cancel the alarm and notification if the alarm is turned off
                    alarmManager.cancel(notifyPendingIntent);
                    mNotificationManager.cancelAll();

                    //Set the toast message for the "off" case
                    toastMessage = getString(R.string.alarm_off_toast);
                }

                //Show a toast to say the alarm is turned on or off
                Toast.makeText(MainActivity.this, toastMessage, Toast.LENGTH_SHORT)
                        .show();
            }
        });
        }


    private void deliverNotification(Context context) {
        Intent contentIntent = new Intent(context, MainActivity.class);
        PendingIntent contentPendingIntent = PendingIntent.getActivity
                (context, NOTIFICATION_ID, contentIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Use  the NotificationCompat.Builder  to  build a notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                .setSmallIcon(R.drawable.ic_stand_up)
                .setContentTitle(context.getString(R.string.notification_title))
                .setContentText(context.getString(R.string.notification_text))
                .setContentIntent(contentPendingIntent)
                //Set the Notification priority to  PRIORITY_HIGH:
                .setPriority(NotificationCompat.PRIORITY_HIGH)
// Set  AutoCancel  to  true, and another option  to  use the default light,  sound and vibration
//pattern
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);
    }

    public void nextAlarm(View view) {


    }
}

/*
package com.example.android.standup;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.Set;

public class MainActivity extends AppCompatActivity {

    NotificationManager mNotificationManager;
    // A	constant	variable	for	the	notification	ID
    private static final int NOTIFICATION_ID = 0;
    // Create	a	string	constant	as	a	member	variable
    private	static	final	String	ACTION_NOTIFY	=
            "com.example.android.standup.ACTION_NOTIFY";
    private Notification.Action.Builder builder;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNotificationManager	=	(NotificationManager)	getSystemService(NOTIFICATION_SERVICE);
        mNotificationManager.notify(NOTIFICATION_ID,	builder.build());


        Intent contentIntent	=	new	Intent(context,	MainActivity.class);
        PendingIntent contentPendingIntent	=	PendingIntent.getActivity
                (context,	NOTIFICATION_ID,	contentIntent,	PendingIntent.FLAG_UPDATE_CURRENT);

        Intent	notifyIntent	=	new	Intent(ACTION_NOTIFY);
        PendingIntent	notifyPendingIntent	=	PendingIntent.getBroadcast
                (this,	NOTIFICATION_ID,	notifyIntent,	PendingIntent.FLAG_UPDATE_CURRENT);

        // useful	for checking whether	the	alarm has	already	been set.
        boolean	alarmUp	=	(PendingIntent.getBroadcast(this,	NOTIFICATION_ID,	notifyIntent,
                PendingIntent.FLAG_NO_CREATE)	!=	null);


        ToggleButton mAlarmToggle = (ToggleButton) findViewById(R.id.alarmToggle);
               mAlarmToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                String	toastMessage;
             */
/*   if(isChecked){
                    //Set	the	toast	message	for	the	"on"	case
                    toastMessage	=	getString(R.string.alarm_on_toast);
                }	else	{
                    //Set	the	toast	message	for	the	"off"	case
                    toastMessage	=	getString(R.string.alarm_off_toast);
                }*//*

                if(isChecked){
                   //Set	the	toast	message	for	the	"on"	case
                    toastMessage	=	getString(R.string.alarm_on_toast);
                }	else	{
                    //Cancel	notification	if	the	alarm	is	turned	off
                    mNotificationManager.cancelAll();
                    //Set	the	toast	message	for	the	"off"	case
                    toastMessage	=	getString(R.string.alarm_off_toast);
                }
//Show	a	toast	to	say	the	alarm	is	turned	on	or	off
                Toast.makeText(MainActivity.this,	toastMessage,	Toast.LENGTH_SHORT)
                        .show();
            }

        });

     final    AlarmManager alarmManager	=	(AlarmManager)	getSystemService(ALARM_SERVICE);
        long	triggerTime	=	SystemClock.elapsedRealtime()
                +	AlarmManager.INTERVAL_FIFTEEN_MINUTES;
        long	repeatInterval	=	AlarmManager.INTERVAL_FIFTEEN_MINUTES;
//If	the	Toggle	is	turned	on,	set	the	repeating	alarm	with	a	15	minute	interval
        alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                triggerTime,	repeatInterval,	notifyPendingIntent);
        alarmManager.cancel(notifyPendingIntent);

    }

    private void  deliverNotification(Context context)  {
        // Use  the NotificationCompat.Builder  to  build a notification
        NotificationCompat.Builder  builder = new NotificationCompat.Builder(context)
                .setSmallIcon(R.drawable.ic_stand_up)
                .setContentTitle(context.getString(R.string.notification_title))
                .setContentText(context.getString(R.string.notification_text))
                .setContentIntent(contentPendingIntent)
                //Set the Notification priority to  PRIORITY_HIGH:
                .setPriority(NotificationCompat.PRIORITY_HIGH)
// Set  AutoCancel  to  true, and another option  to  use the default light,  sound and vibration
//pattern
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);
    }

}*/
