package com.example.android.whowroteitloader;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;

public class BookLoader extends AsyncTaskLoader<String> {
    // Variable that store the search result string
    private String mQueryString;

    public BookLoader(@NonNull Context context, String queryString) {
        super(context);
        mQueryString = queryString;
    }

    // This is call whenever the loader is started
    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad(); // start the loadInBackground method
    }

    @Nullable
    @Override
    public String loadInBackground() {
        return NetworkUtils.getBookInfo(mQueryString);

    }
}
